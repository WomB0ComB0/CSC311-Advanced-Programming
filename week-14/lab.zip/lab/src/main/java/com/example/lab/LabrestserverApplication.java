package com.example.labrestserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

 @SpringBootApplication
public class LabrestserverApplication {
    public static void main(String[] args) {
        SpringApplication.run(LabrestserverApplication.class, args);
    }
}
